----Zwoptex------

If you have an Apple computer, you can download Zwoptex here to edit the sprite sheet:
http://www.zwopple.com/zwoptex/

If you're on windows, you can use texture packer instead:
http://www.codeandweb.com/texturepacker

***Using texture packer will mean you have to repackage everything yourself.  Sorry for the inconvenience.  

----Attribute----
CC-By-3.0
GPL 2.0
GPL 3.0

Original Artwork: Curt
http://opengameart.org/content/characters-zombies-and-weapons-oh-my

----Changes----

Version 1: This doesn't include all the parts I currently have in GIMP.  This was asked to be added after and I'll try to keep the GIMP assets and this part sheet in sync after this release.

